from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
### functions or classes are mapped to urls

def index(request):
    return HttpResponse("Welcome To Krish Study TimeTable")

def monday(request):
    return HttpResponse("Today I am learning Data Science")

def tuesday(request):
    return HttpResponse("Today I am learning Big Data")

def weekly_timetable(request,day):
    text=""
    if day=="monday":
        text="I will learn data science"
    elif day=="tuesday":
        text="Today I am learning Big Data"
    return HttpResponse(text)

